CREATE DATABASE KitchenKeeper
GO

USE KitchenKeeper

CREATE TABLE Users
(
  UserID int IDENTITY(1,1) NOT NULL,
  FirstName nvarchar(max),
  LastName nvarchar(max),
  Email nvarchar(max) NOT NULL UNIQUE,
  Password nvarchar(max) NOT NULL, --Store password hashes for increased security
  Admin bit NOT NULL
)
GO

CREATE TABLE StorageLocations
(
  LocationID int IDENTITY(1,1) NOT NULL,
  LocationName nvarchar(max)
)
GO

CREATE TABLE Items
(
  ItemID int IDENTITY(1,1) NOT NULL,
  ItemName nvarchar(max) NOT NULL,
  Quantity decimal(18, 2) NOT NULL,
  UnitOfMeasure nvarchar(max) NOT NULL,
  PurchaseDate datetime2(7) NULL,
  ExpirationDate datetime2(7) NULL,
  LocationID int NOT NULL FOREIGN KEY REFERENCES StorageLocations(LocationID)
)
GO

CREATE TABLE PDFs
(
  ItemID int NOT NULL PRIMARY KEY FOREIGN KEY REFERENCES Items(ItemID),
  Content varbinary(max) NOT NULL
)
GO

CREATE TABLE JSONs
(
  ItemID int NOT NULL PRIMARY KEY FOREIGN KEY REFERENCES Items(ItemID),
  Content varbinary(max) NOT NULL
)
GO